class FavoriteService {
  constructor() {
    this.STORAGE_KEY = 'favorite_sites';
    this.BOOKMARK_FOLDER_NAME = '..lokica_backup';
    this.MAX_BACKUP_VERSIONS = 5;
    this.MAX_ITEMS = 100;
    this.MAX_RETRIES = 3;
    this.RETRY_DELAY = 1000;
    
    this.initStorage();
    this.initStorageListener();
  }

  // 添加重试逻辑的包装函数
  async withRetry(operation, maxRetries = this.MAX_RETRIES) {
    let lastError;
    for (let i = 0; i < maxRetries; i++) {
      try {
        return await operation();
      } catch (error) {
        lastError = error;
        console.warn(`Retry ${i + 1}/${maxRetries} failed:`, error);
        if (i < maxRetries - 1) {
          await new Promise(resolve => setTimeout(resolve, this.RETRY_DELAY));
        }
      }
    }
    throw lastError;
  }

  // 创建或获取备份文件夹
  async getBackupFolder() {
    try {
      // 先尝试找到现有的备份文件夹
      const results = await chrome.bookmarks.search({ title: this.BOOKMARK_FOLDER_NAME });
      if (results.length > 0) {
        return results[0];
      }

      // 如果没有找到，创建一个新的隐藏文件夹
      const otherBookmarks = await chrome.bookmarks.get('2');
      if (!otherBookmarks || !otherBookmarks[0]) {
        throw new Error('Could not find other bookmarks folder');
      }

      // 创建隐藏的备份文件夹在"其他书签"中
      return await chrome.bookmarks.create({
        parentId: '2',
        title: this.BOOKMARK_FOLDER_NAME,
        index: 0
      });
    } catch (error) {
      console.error('Error getting backup folder:', error);
      return null;
    }
  }

  // 保存到书签
  async backupToBookmarks(favorites) {
    try {
      const folder = await this.getBackupFolder();
      if (!folder) return;

      // 获取现有的备份
      const children = await chrome.bookmarks.getChildren(folder.id);
      
      // 创建新的备份数据，添加随机数确保唯一性
      const backupData = {
        version: Date.now(),
        random: Math.random().toString(36).slice(2, 8), // 添加随机字符串
        data: favorites
      };
      
      // 压缩成JSON字符串
      const compressedData = JSON.stringify(backupData);
      
      // 创建新的备份书签，使用时间戳_随机数作为唯一标识
      await chrome.bookmarks.create({
        parentId: folder.id,
        title: `..backup_${backupData.version}_${backupData.random}`,
        url: `data:text/plain;charset=utf-8,${encodeURIComponent(compressedData)}`
      });

      // 如果超过最大版本数，删除最旧的版本
      if (children.length >= this.MAX_BACKUP_VERSIONS) {
        const sortedChildren = children
          .sort((a, b) => {
            // 只使用时间戳部分进行排序
            const versionA = parseInt(a.title.split('_')[1]) || 0;
            const versionB = parseInt(b.title.split('_')[1]) || 0;
            return versionB - versionA;
          });

        // 获取需要删除的旧版本
        const versionsToDelete = sortedChildren.slice(this.MAX_BACKUP_VERSIONS);
        
        // 删除旧版本
        await Promise.all(versionsToDelete.map(child => chrome.bookmarks.remove(child.id)));
      }
    } catch (error) {
      console.error('Error backing up to bookmarks:', error);
    }
  }

  // 从书签恢复
  async restoreFromBookmarks() {
    try {
      const folder = await this.getBackupFolder();
      if (!folder) return null;

      const bookmarks = await chrome.bookmarks.getChildren(folder.id);
      if (!bookmarks || bookmarks.length === 0) return null;

      // 获取最新的备份
      const latestBackup = bookmarks
        .sort((a, b) => {
          const versionA = parseInt(a.title.split('_')[1]) || 0;
          const versionB = parseInt(b.title.split('_')[1]) || 0;
          return versionB - versionA;
        })[0];

      if (!latestBackup) return null;

      // 解析URL中的数据
      const compressedData = decodeURIComponent(latestBackup.url.replace('data:text/plain;charset=utf-8,', ''));
      const backupData = JSON.parse(compressedData);

      return backupData.data;
    } catch (error) {
      console.error('Error restoring from bookmarks:', error);
      return null;
    }
  }

  async initStorage() {
    try {
      // 先检查同步存储
      const syncData = await this.getSyncData();
      
      // 如果同步存储为空，尝试从书签恢复
      if (!syncData || syncData.length === 0) {
        const bookmarkData = await this.restoreFromBookmarks();
        if (bookmarkData && bookmarkData.length > 0) {
          console.log('Restoring from bookmarks backup');
          await this.withRetry(async () => {
            await this.saveSyncData(bookmarkData);
          });
          return bookmarkData;
        }
      } else {
        // 如果有同步数据，更新书签备份
        await this.backupToBookmarks(syncData);
        return syncData;
      }
      
      return [];
    } catch (error) {
      console.error('Failed to initialize storage:', error);
      return [];
    }
  }

  initStorageListener() {
    chrome.storage.onChanged.addListener((changes, namespace) => {
      if (namespace === 'sync' && changes[this.STORAGE_KEY]) {
        const newData = changes[this.STORAGE_KEY].newValue;
        // 更新书签备份
        this.backupToBookmarks(newData);
        // 触发UI更新事件
        this.triggerChangeEvent(newData);
      }
    });
  }

  triggerChangeEvent(data) {
    const event = new CustomEvent('favoritesChanged', {
      detail: data
    });
    window.dispatchEvent(event);
  }

  async getSyncData() {
    return new Promise((resolve) => {
      chrome.storage.sync.get([this.STORAGE_KEY], (result) => {
        resolve(result[this.STORAGE_KEY] || []);
      });
    });
  }

  async saveSyncData(data) {
    return new Promise((resolve, reject) => {
      chrome.storage.sync.set({ [this.STORAGE_KEY]: data }, () => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else {
          resolve();
        }
      });
    });
  }

  async saveFavorites(favorites) {
    return this.withRetry(async () => {
      // 保存到同步存储
      await this.saveSyncData(favorites);
      
      // 同时备份到书签
      await this.backupToBookmarks(favorites);
      
      return true;
    });
  }

  async getFavorites() {
    try {
      const syncData = await this.getSyncData();
      return syncData || [];
    } catch (error) {
      console.error('Error getting favorites:', error);
      return [];
    }
  }

  async addFavorite(site) {
    try {
      const favorites = await this.getFavorites();
      
      if (favorites.some(f => f.url === site.url)) {
        return false;
      }
      
      if (favorites.length >= this.MAX_ITEMS) {
        throw new Error('Maximum favorites limit reached');
      }

      const newFavorite = {
        url: site.url,
        title: site.title,
        favicon: site.favicon,
        addedAt: new Date().toISOString(),
        order: favorites.length
      };
      
      favorites.push(newFavorite);
      await this.saveFavorites(favorites);
      return true;
    } catch (error) {
      console.error('Error adding favorite:', error);
      throw error;
    }
  }

  async removeFavorite(url) {
    try {
      const favorites = await this.getFavorites();
      const newFavorites = favorites.filter(f => f.url !== url);
      await this.saveFavorites(newFavorites);
      return true;
    } catch (error) {
      console.error('Error removing favorite:', error);
      return false;
    }
  }

  async isFavorite(url) {
    try {
      const favorites = await this.getFavorites();
      return favorites.some(f => f.url === url);
    } catch (error) {
      console.error('Error checking favorite status:', error);
      return false;
    }
  }

  async updateOrder(favorites) {
    try {
      const updatedFavorites = favorites.map((item, index) => ({
        ...item,
        order: index
      }));
      await this.saveFavorites(updatedFavorites);
      return true;
    } catch (error) {
      console.error('Error updating order:', error);
      return false;
    }
  }
}

export default new FavoriteService(); 