// 图标默认路径
const DEFAULT_ICON = chrome.runtime.getURL('icons/default-icon.png');

class IconService {
  // 添加静态属性确保默认图标加载成功
  static defaultIconLoaded = false;
  
  // 图标缓存
  static iconCache = new Map();
  
  /**
   * 获取网站图标
   * @param {string} url - 网站 URL
   * @param {string} [customIcon] - 可选的自定义图标 URL
   * @returns {Promise<string>} - 返回图标 URL
   */
  static async getFavicon(url, customIcon = null) {
    // 检查缓存
    const cacheKey = url + (customIcon || '');
    if (this.iconCache.has(cacheKey)) {
      return this.iconCache.get(cacheKey);
    }

    let iconUrl;
    if (customIcon) {
      iconUrl = customIcon;
    } else if (!url || url.startsWith('chrome://') || url.startsWith('chrome-extension://')) {
      iconUrl = DEFAULT_ICON;
    } else {
      try {
        const domain = new URL(url).hostname;
        // 使用 DuckDuckGo 的 favicon 服务作为替代
        iconUrl = `https://icons.duckduckgo.com/ip3/${domain}.ico`;
      } catch (e) {
        console.error('Invalid URL:', url);
        iconUrl = DEFAULT_ICON;
      }
    }

    // 更新缓存
    this.iconCache.set(cacheKey, iconUrl);
    return iconUrl;
  }

  /**
   * 创建图标元素
   * @param {string} url - 网站 URL
   * @param {string} [customIcon] - 可选的自定义图标 URL
   * @returns {HTMLImageElement} - 返回图标元素
   */
  static createIconElement(url, customIcon = null) {
    const img = document.createElement('img');
    img.width = 16;
    img.height = 16;
    img.src = DEFAULT_ICON;

    if (!url || url.startsWith('chrome://') || url.startsWith('chrome-extension://')) {
      return img;
    }

    // 异步加载图标
    this.getFavicon(url, customIcon)
      .then(iconUrl => {
        img.src = iconUrl;
      })
      .catch(() => {
        img.src = DEFAULT_ICON;
      });

    // 添加错误处理
    img.onerror = () => {
      img.src = DEFAULT_ICON;
    };

    return img;
  }

  /**
   * 清除图标缓存
   * @param {string} [url] - 可选的特定 URL，如果不提供则清除所有缓存
   */
  static clearCache(url = null) {
    if (url) {
      this.iconCache.delete(url);
    } else {
      this.iconCache.clear();
    }
  }
}

export default IconService; 