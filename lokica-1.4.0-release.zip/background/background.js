// 创建悬浮入口
function createFloatingButton() {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs[0]) {
      chrome.scripting.executeScript({
        target: { tabId: tabs[0].id },
        function: injectFloatingButton
      });
    }
  });
}

// 注入悬浮按钮到页面
function injectFloatingButton() {
  // 如果已存在则不重复创建
  if (document.getElementById('lokica-floating-btn')) return;

  const button = document.createElement('div');
  button.id = 'lokica-floating-btn';
  button.innerHTML = `
    <img src="${chrome.runtime.getURL('icons/icon-48.png')}" alt="Lokica">
  `;
  
  // 添加样式
  const style = document.createElement('style');
  style.textContent = `
    #lokica-floating-btn {
      position: fixed;
      right: 20px;
      bottom: 20px;
      width: 20px;
      height: 20px;
      border-radius: 50%;
      background: white;
      box-shadow: 0 2px 8px rgba(0,0,0,0.15);
      cursor: pointer;
      z-index: 2147483647;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: transform 0.2s;
    }
    
    #lokica-floating-btn:hover {
      transform: scale(1.1);
    }
    
    #lokica-floating-btn img {
      width: 32px;
      height: 32px;
    }
  `;
  
  // 添加点击事件
  button.addEventListener('click', () => {
    chrome.runtime.sendMessage({ action: 'openSidePanel' });
  });
  
  document.head.appendChild(style);
  document.body.appendChild(button);
}

// 监听消息
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'openSidePanel') {
    chrome.sidePanel.open({ windowId: chrome.windows.WINDOW_ID_CURRENT });
  }
});

// 在安装时创建悬浮入口
chrome.runtime.onInstalled.addListener(() => {
  createFloatingButton();
});

// 在页面加载完成时创建悬浮入口
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url.startsWith('http')) {
    createFloatingButton();
  }
});